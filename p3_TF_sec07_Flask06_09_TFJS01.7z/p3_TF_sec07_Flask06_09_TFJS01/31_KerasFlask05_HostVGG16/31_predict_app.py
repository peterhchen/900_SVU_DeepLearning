import base64
import numpy as np
import io
from PIL import Image
import keras
from tensorflow.keras import backend as K
from tensorflow.keras.models import Sequential
#from tensorflow.keras.models import load_model
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing.image import img_to_array
from flask import request
from flask import jsonify
from flask import Flask

app = Flask(__name__)

def get_model():
    global model
    #model = load_model('VGG16_cats_and_dogs.h5')
    # VGG16_cats_and_dogs.h5 is 500MB is to big to download
    # https://github.com/prashant0598/Keras-Machine-Learning-Deep-Learning-Tutorial/tree/master/flask_apps
    # new_model = load_model('models/medical_trial_model.h5')
    # I save the VGG16_cats_and_dogs.h5 from sec03_TF_VGG16 in Episode 15: TrainFineTuneVGG16.
    model = load_model('../../models/VGG16_cats_and_dogs.h5')
    print(" * Model loaded!")

def preprocess_image(image, target_size):
    if image.mode != "RGB":
        image = image.convert("RGB")
    image = image.resize(target_size)
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)

    return image


print(" * Loading Keras model...")
get_model()

@app.route("/predict", methods=["POST"])
def predict():
    message = request.get_json(force=True)
    encoded = message['image']
    decoded = base64.b64decode(encoded)
    image = Image.open(io.BytesIO(decoded))
    processed_image = preprocess_image(image, target_size=(224, 224))
    
    prediction = model.predict(processed_image).tolist()

    response = {
        'prediction': {
            'dog': prediction[0][0],
            'cat': prediction[0][1]
        }
    }
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)