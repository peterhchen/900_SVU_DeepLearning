The VGG16_cats_and_dogs.h5 file is too large to upload to Github.
Download it here:
https://drive.google.com/open?id=19yICdtSbU_YkQBRxJ2if9KJwUL1oY5xs
