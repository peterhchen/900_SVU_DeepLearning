let express = require("express");
let app = express();

// Note:
// the next() is the middleware will be called first.
// before the app.get() get called.
app.use(function(req, res, next) {
    console.log(`${new Date()} - ${req.method} request for ${req.url}`);
    next();
});

// http://localhost:81/
app.get('/', function (req, res) {
    res.send('root: Hello World!')
})

// http://localhost:81/abc
app.get('/abc', function (req, res) {
    res.send('/abc: Hello World!')
})


const path = require('path');
// http://localhost:81/hello
app.get('/hello', function (req, res) {
    res.sendFile(path.join(__dirname+'/static/hello.html'))
})
// http://localhost:81/predict
app.get('/predict', function (req, res) {
    res.sendFile(path.join(__dirname+'/static/predict.html'))
})

app.use(express.static("../static"));

app.listen(81, function() {
    console.log("Serving static on 81");
});